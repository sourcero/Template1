<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks_39355c36cfd8f1d048a1f84803963534'] = 'Bloc liens permanents';
$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks_6c5b993889148d10481569e55f8f7c6d'] = 'Ajoute un bloc qui affiche des liens permanents (contact, plan du site, etc.).';
$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks-footer_5813ce0ec7196c492c97596718f71969'] = 'sitemap';
$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks-footer_bbaff12800505b22a853e8b7f4eb6a22'] = 'Contact';
$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks-footer_714814d37531916c293a8a4007e8418c'] = 'Mettre cette page en favori';
$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks-header_2f8a6bf31f3bd67bd2d9720c58b19c9a'] = 'contact';
$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks-header_e1da49db34b0bdfdddaba2ad6552f848'] = 'plan du site';
$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks-header_fad9383ed4698856ed467fd49ecf4820'] = 'favoris';
$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks_c46000dc35dcefd6cc33237fa52acc48'] = 'plan de la boutique';
$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks_5813ce0ec7196c492c97596718f71969'] = 'sitemap';
$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks_c661cf76442d8d2cb318d560285a2a57'] = 'Formulaire de contact';
$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks_bbaff12800505b22a853e8b7f4eb6a22'] = 'Contact';
$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks_2d29fbe96aaeb9737b355192f4683690'] = 'Mettre cette page en favori';


return $_MODULE;

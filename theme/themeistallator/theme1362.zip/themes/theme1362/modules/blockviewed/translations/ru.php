<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockviewed}prestashop>blockviewed_859e85774d372c6084d62d02324a1cc3'] = 'Блок просмотренных товаров';
$_MODULE['<{blockviewed}prestashop>blockviewed_eaa362292272519b786c2046ab4b68d2'] = 'Добавляет блок последних просмотренных товаров.';
$_MODULE['<{blockviewed}prestashop>blockviewed_2e57399079951d84b435700493b8a8c1'] = 'Вы должны заполнить поле \'Отображать товаров\'.';
$_MODULE['<{blockviewed}prestashop>blockviewed_73293a024e644165e9bf48f270af63a0'] = 'Неверный номер.';
$_MODULE['<{blockviewed}prestashop>blockviewed_f38f5974cdc23279ffe6d203641a8bdf'] = 'Настройки обновлены.';
$_MODULE['<{blockviewed}prestashop>blockviewed_f4f70727dc34561dfde1a3c529b6205c'] = 'Настройки';
$_MODULE['<{blockviewed}prestashop>blockviewed_26986c3388870d4148b1b5375368a83d'] = 'Число отображаемых товаров';
$_MODULE['<{blockviewed}prestashop>blockviewed_d36bbb6066e3744039d38e580f17a2cc'] = 'Укажите количество товаров, отображаемых в блоке';
$_MODULE['<{blockviewed}prestashop>blockviewed_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить';
$_MODULE['<{blockviewed}prestashop>blockviewed_43560641f91e63dc83682bc598892fa1'] = 'Просмотренные товары';
$_MODULE['<{blockviewed}prestashop>blockviewed_8f7f4c1ce7a4f933663d10543562b096'] = 'Подробнее';
$_MODULE['<{blockviewed}prestashop>blockviewed_c70ad5f80e4c6f299013e08cabc980df'] = 'Подробнее о %s';


return $_MODULE;
